Reflection
1- The coding portion of the assignment was straight-forward enough that even us rookies could understand.
2- The only hiccup that we had was pushing these files to Git, but after some experimenting and some trial and error, we got it figured out.
3- Our team works well together and is extremely patient along every step.
4- We are excited for the next challenge.
