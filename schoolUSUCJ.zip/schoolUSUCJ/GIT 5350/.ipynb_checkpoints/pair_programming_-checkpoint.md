09.16.TH, 12:00p - 1:00p Cooper and Taylor, 1 hour
Driver order and time length:
Taylor, 30 minutes
Cooper, 30 minutes
