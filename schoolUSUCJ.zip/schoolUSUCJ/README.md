# CF-GIT
Playing with Git for school
