Reflection

1) I felt really good about completing this assignment because I felt my understanding deepen as I wrestled with both conceptual understanding and programming.
2) The pair programming is extremely beneficial for me because not only do we think differently about problems, my team has a lot of quantitative skills.
3) I wish I would have started on this assingment sooner.  I have really struggled with motivation in programming, but this assignment restored a little faith.