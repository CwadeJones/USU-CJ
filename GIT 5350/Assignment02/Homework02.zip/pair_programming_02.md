11.03.TU, 4:00p - 7:00p Taylor and Cooper, 3 hours
Driver order and time length:
Taylor, 90 minutes
Cooper, 90 minutes

