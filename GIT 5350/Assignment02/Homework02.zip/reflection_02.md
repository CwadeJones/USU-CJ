Reflection

1- This assignment has been challenging to say the least.  Our group has struggled to use effectient code from the start.  We have spent a lot of time working and reworking our code to find the most effecient solution.
2- Formal pair programming has been helpful.  It is interesting to see how each member of the group goes about solving problems through our computational thinking.
3- We are happy to say that we have figured out how to code the last few lines of our code.
4- The consensus is that we will revisit the videos on canvas and recommit our info to the cloud.